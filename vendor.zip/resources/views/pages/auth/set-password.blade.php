@extends('layout.app')
@section('content')
    @include('components.auth.set-password')
@endsection