@extends('layout.app')
@section('content')
    @include('components.auth.email')
@endsection