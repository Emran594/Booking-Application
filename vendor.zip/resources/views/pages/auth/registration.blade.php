@extends('layout.app')
@section('content')
    @include('components.auth.registration-form')
@endsection